1. I use Oracle 11 xe version.
2. I use Tomcat 8.0 or 8.5 version


Homeowner Insurance is a home insurance company that aidsits customers to apply for insurance and purchase homes.

This (platform) project has been made in order to make the services of Homeowners easy and accessible with the rise of IT and the ease its provides to users.

Users are able to create accounts on the platform with a UNIQUE USER ID and PASSWORD.

After USERS login, they are able to Get a quote on their homes and also RETRIVE a quote which is already updated on the users account.

Users can login with an existing account or create a new account and be added to the platform as new users.

Users who create new accounts are required to fill all text fields to create accounts succesfully.

Invalid logins provided will be denied entry and a pop notification shown to the user. (put the snapshot that shows user shoul put in valid user ID)

After a successful login users can "Get a quote" for their bulding or "Request Quote" to pull out an existing or saved quote.

Most fields are filled with constrains that enable the user to input realistic values (screenshot of some pages with logins)

All the data submitted to the system is stored in a database(Oracle Database) for future reference .

Prices of packages being it monthly and so on are displayed to users as well as the OPTION to proceed to buy insurance to cover their properties.

synced and saved over a database and sent to the HomeownerInsurace for review. Admins have the right to create or delete user accounts as well as edit some information submitted.

This platform is robust and secure as users can process all request and have their needs serviced at a go.