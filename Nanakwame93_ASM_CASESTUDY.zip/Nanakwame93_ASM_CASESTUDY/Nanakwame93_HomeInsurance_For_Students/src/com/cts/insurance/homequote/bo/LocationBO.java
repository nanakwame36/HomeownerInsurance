/**
 * This Business Object class is used to for Location Information
 * 
 * @author Cognizant
 * @contact Cognizant
 * @version 1.0
 */
package com.cts.insurance.homequote.bo;

import java.util.List;

import com.cts.insurance.homequote.dao.LocationDAO;
import com.cts.insurance.homequote.exception.HomequoteBusinessException;
import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.Location;

public class LocationBO {

	/**
	 * @param location
	 * @return
	 * @throws HomequoteBusinessException
	 * @throws HomequoteSystemException 
	 */
	public int saveHomeLocation(final Location location) throws HomequoteBusinessException, HomequoteSystemException{

		final LocationDAO locationDAO = new LocationDAO();
		//Fill code here
		
		return locationDAO.saveLocation(location); //return integer
	}
	
	/**
	 * @return
	 * @throws HomequoteBusinessException
	 * @throws HomequoteSystemException 
	 */
	public Location getHomeLocation(int quoteId) throws HomequoteBusinessException, HomequoteSystemException{

		final LocationDAO locationDAO = new LocationDAO();
		//Fill code here
		Location loc=null;
		loc=locationDAO.getLocation(quoteId);
		return loc; //return Object
	}
	
	/**
	 * @return
	 * @throws HomequoteBusinessException
	 * @throws HomequoteSystemException 
	 */
	public List<Location> getQuoteIds(String userName) throws HomequoteBusinessException, HomequoteSystemException{

		final LocationDAO locationDAO = new LocationDAO();
		//Fill code here
		List<Location> list=null;
		list=locationDAO.getQuoteIds(userName);
		return list; //return    lst of Object
	}
	
}
