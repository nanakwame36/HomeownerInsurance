/**
 * This DAO class is used to for Homeowner Information
 *
 * @author Cognizant
 * @contact Cognizant
 * @version 1.0
 */
package com.cts.insurance.homequote.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.log.LogInitializer;
import com.cts.insurance.homequote.model.Homeowner;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;
import com.cts.insurance.homequote.util.SqlQueries;

public class HomeownerDAO {
	
	private final static Logger LOG = Logger.getLogger(HomeownerDAO.class);
	String url="jdbc:oracle:thin:@localhost:1521:orcl";
	String user="C##CASESTUDY";
	String password="password";
	/**
	 * @param homeowner
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public void saveHomeowner(final Homeowner homeowner) throws HomequoteSystemException, ClassNotFoundException, IOException
	{
		LOG.info("HomeownerDAO.saveHomeowner - starts");
		Connection conn = null;
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			stmt=conn.prepareStatement(SqlQueries.SAVE_HOMEOWNER);
			
			stmt.setInt(1,homeowner.getQuoteId() );
			stmt.setString(2,homeowner.getFirstName());
			stmt.setString(3,homeowner.getLastName());
			stmt.setString(4,homeowner.getDob());
			stmt.setString(5,homeowner.getIsRetired());
			stmt.setString(6,homeowner.getSsn());
			stmt.setString(7,homeowner.getEmailAddress());
					
			stmt.executeUpdate();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Fill code here
	}
	

	/**
	 * @param homeowner
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public Homeowner getHomeowner(final int quoteId) throws HomequoteSystemException, ClassNotFoundException, IOException
	{
		LOG.info("HomeownerDAO.getHomeowner - starts");
		Connection conn = null;
		Homeowner homeowner = null;
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		//Fill code here
	
		try {
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			homeowner=new Homeowner();
			stmt=conn.prepareStatement(SqlQueries.GET_HOMEOWNER);
			stmt.setInt(1, quoteId);
			resultSet = stmt.executeQuery();
			while(resultSet.next()) {
				homeowner.setQuoteId(resultSet.getInt(1));//QUOTE_ID
				//homeowner.setQuoteId(resultSet.getInt("QUOTE_ID"));
				homeowner.setFirstName(resultSet.getString("FIRST_NAME"));
				homeowner.setLastName(resultSet.getString("LAST_NAME"));
				homeowner.setDob(resultSet.getString("DOB"));
				homeowner.setIsRetired(resultSet.getString("IS_RETIRED"));
				homeowner.setSsn(resultSet.getString("SSN"));
				homeowner.setEmailAddress(resultSet.getString("EMAIL_ADDRESS"));
			}
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return homeowner; //return Object
	}

}
